//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dgu1MMca.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/account",
			"/goals",
			"/more",
			"/stats",
			"/tasks",
			"/timing"
		],
		preloads: ["/assets/index-hmKZfJj5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-hmKZfJj5.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DX7NQIL4.js", "/assets/score-pips-Cgpp0Gy5.js"]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-CtQv5jy2.js",
			"/assets/client-CvKYS2ZC.js",
			"/assets/modal-CjAQ0vs7.js",
			"/assets/desktop-download-cb0caYdq.js"
		]
	},
	"/goals": {
		filePath: "/workspace/src/routes/goals.tsx",
		children: void 0,
		preloads: ["/assets/goals-DNhWEdqx.js", "/assets/modal-CjAQ0vs7.js"]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-zpnf82uI.js",
			"/assets/modal-CjAQ0vs7.js",
			"/assets/desktop-download-cb0caYdq.js"
		]
	},
	"/stats": {
		filePath: "/workspace/src/routes/stats.tsx",
		children: void 0,
		preloads: ["/assets/stats-ClMVCB_M.js"]
	},
	"/tasks": {
		filePath: "/workspace/src/routes/tasks.tsx",
		children: void 0,
		preloads: ["/assets/tasks-sC-P0yC9.js", "/assets/modal-CjAQ0vs7.js"]
	},
	"/timing": {
		filePath: "/workspace/src/routes/timing.tsx",
		children: void 0,
		preloads: [
			"/assets/timing-CFh-BbbC.js",
			"/assets/modal-CjAQ0vs7.js",
			"/assets/score-pips-Cgpp0Gy5.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
