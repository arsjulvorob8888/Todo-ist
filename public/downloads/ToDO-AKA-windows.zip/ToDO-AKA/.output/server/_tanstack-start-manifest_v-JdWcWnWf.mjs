//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-JdWcWnWf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/account",
			"/goals",
			"/more",
			"/stats",
			"/tasks",
			"/timing"
		],
		preloads: ["/assets/index-CNvZ-nOj.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CNvZ-nOj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C4csTFpr.js", "/assets/score-pips-CRXmwERe.js"]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-v8Xvy6Pt.js",
			"/assets/client-CK9_dW15.js",
			"/assets/modal-B4gnpaV3.js",
			"/assets/desktop-download-Dcpv5I2f.js"
		]
	},
	"/goals": {
		filePath: "/workspace/src/routes/goals.tsx",
		children: void 0,
		preloads: ["/assets/goals-CRH19zDR.js", "/assets/modal-B4gnpaV3.js"]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-C3wy8r34.js",
			"/assets/modal-B4gnpaV3.js",
			"/assets/desktop-download-Dcpv5I2f.js"
		]
	},
	"/stats": {
		filePath: "/workspace/src/routes/stats.tsx",
		children: void 0,
		preloads: ["/assets/stats-Cz2nSdrs.js"]
	},
	"/tasks": {
		filePath: "/workspace/src/routes/tasks.tsx",
		children: void 0,
		preloads: ["/assets/tasks-QZCDj5Oa.js", "/assets/modal-B4gnpaV3.js"]
	},
	"/timing": {
		filePath: "/workspace/src/routes/timing.tsx",
		children: void 0,
		preloads: [
			"/assets/timing-Ba6efOuS.js",
			"/assets/modal-B4gnpaV3.js",
			"/assets/score-pips-CRXmwERe.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
