import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as playStart, v as usePlanner } from "./router-aju2iEXR.mjs";
import { n as Modal, r as inputClass, t as Field } from "./modal-B9fcrG3Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-BXz3nNAS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRIORITIES = [
	"Срочно",
	"Высокий",
	"Средний",
	"Низкий"
];
function TasksView() {
	const tasks = usePlanner((s) => s.tasks);
	const projects = usePlanner((s) => s.projects);
	const addTask = usePlanner((s) => s.addTask);
	const completeTask = usePlanner((s) => s.completeTask);
	const deleteTask = usePlanner((s) => s.deleteTask);
	const updateTask = usePlanner((s) => s.updateTask);
	const boards = usePlanner((s) => s.boards);
	const labels = usePlanner((s) => s.labels);
	const addLabel = usePlanner((s) => s.addLabel);
	const startPomo = usePlanner((s) => s.startPomo);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("Все");
	const [project, setProject] = (0, import_react.useState)("Все");
	const [labelId, setLabelId] = (0, import_react.useState)("Все");
	const [labelName, setLabelName] = (0, import_react.useState)("");
	const visible = tasks.filter((task) => {
		if (filter !== "Все" && task.status !== filter) return false;
		if (project !== "Все" && task.projectId !== project && task.project !== project) return false;
		if (labelId !== "Все" && !(task.labelIds ?? []).includes(labelId)) return false;
		return true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-5 flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Одно действие — одна цель"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Задачи"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "rounded-full bg-gold px-4 py-2 text-ink",
				children: "Новая"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [[
				"Все",
				"В ожидании",
				"В процессе",
				"Выполнено"
			].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(name),
				className: `rounded-full px-3 py-2 text-sm ${filter === name ? "bg-gold text-ink" : "bg-panel text-mist"}`,
				children: name
			}, name)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: inputClass + " w-auto",
				value: project,
				onChange: (event) => setProject(event.target.value),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "Все",
					children: "Все проекты"
				}), boards.map((board) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: board.id,
					children: board.name
				}, board.id))]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLabelId("Все"),
					className: `rounded-full px-3 py-1 text-sm ${labelId === "Все" ? "bg-gold text-ink" : "bg-panel text-mist"}`,
					children: "Все метки"
				}),
				labels.map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLabelId(label.id),
					className: `rounded-full px-3 py-1 text-sm ${labelId === label.id ? "text-ink" : "text-cream"}`,
					style: {
						background: labelId === label.id ? label.color : "transparent",
						border: `1px solid ${label.color}`
					},
					children: label.name
				}, label.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass + " w-36",
					placeholder: "Новая метка",
					value: labelName,
					onChange: (event) => setLabelName(event.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-panel-2 px-3 py-2 text-sm",
					onClick: () => {
						addLabel(labelName);
						setLabelName("");
					},
					children: "Метка"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: visible.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
				task,
				labels,
				onDone: () => completeTask(task.id),
				onDelete: () => deleteTask(task.id),
				onEdit: () => setEditing(task),
				onProgress: () => updateTask(task.id, { status: "В процессе" }),
				onPomo: () => {
					playStart();
					startPomo(25, task.id);
				}
			}, task.id))
		}),
		visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-mist",
			children: [tasks.length === 0 ? "Нет задач в этом фильтре." : "В этом фильтре пусто.", tasks.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "ml-3 rounded-full bg-gold px-3 py-1 text-ink",
				onClick: () => {
					setFilter("Все");
					setProject("Все");
				},
				children: [
					"Показать все (",
					tasks.length,
					")"
				]
			}) : null]
		}) : null,
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskForm, {
			projects,
			boards,
			labels,
			onClose: () => setOpen(false),
			onSave: (task) => {
				addTask(task);
				setFilter("Все");
				setProject("Все");
			}
		}) : null,
		editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskForm, {
			projects,
			boards,
			labels,
			initial: editing,
			onClose: () => setEditing(null),
			onSave: (task) => {
				updateTask(editing.id, task);
				setEditing(null);
			}
		}) : null
	] });
}
function TaskRow({ task, labels, onDone, onDelete, onEdit, onProgress, onPomo }) {
	const done = task.status === "Выполнено";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 rounded-card border border-line bg-panel px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": done ? "Вернуть в работу" : "Выполнить",
				onClick: onDone,
				className: `flex size-8 shrink-0 items-center justify-center rounded-full border-2 text-sm font-bold ${done ? "border-gold bg-gold text-ink" : "border-gold"}`,
				children: done ? "✓" : ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: done ? "text-mist line-through" : "",
						children: task.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-mist",
						children: [
							"Поставлена ",
							formatCreated(task.created),
							" · дедлайн ",
							formatDeadline(task.deadline),
							" · ",
							task.priority,
							" · ",
							task.status
						]
					}),
					(task.labelIds ?? []).length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 flex flex-wrap gap-1",
						children: labels.filter((label) => (task.labelIds ?? []).includes(label.id)).map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full px-2 py-0.5 text-xs text-ink",
							style: { background: label.color },
							children: label.name
						}, label.id))
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onEdit,
				className: "text-sm text-gold",
				children: "Править"
			}),
			!done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onProgress,
				className: "hidden text-sm text-mist sm:block",
				children: "В работе"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onPomo,
				className: "rounded-full bg-gold px-3 py-2 text-sm text-ink",
				children: "25 мин"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onDelete,
				className: "text-sm text-ember",
				children: "Удалить"
			})
		]
	});
}
function TaskForm({ projects, boards, labels, initial, onClose, onSave }) {
	const [title, setTitle] = (0, import_react.useState)(initial?.title ?? "");
	const [projectId, setProjectId] = (0, import_react.useState)(initial?.projectId || boards.find((board) => board.name === initial?.project)?.id || boards.find((board) => board.inbox)?.id || "");
	const [priority, setPriority] = (0, import_react.useState)(initial?.priority ?? "Средний");
	const [deadline, setDeadline] = (0, import_react.useState)(initial?.deadline ?? "");
	const [description, setDescription] = (0, import_react.useState)(initial?.description ?? "");
	const [picked, setPicked] = (0, import_react.useState)(initial?.labelIds ?? []);
	const [error, setError] = (0, import_react.useState)("");
	const board = boards.find((item) => item.id === projectId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: initial ? "Править задачу" : "Новая задача",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Текст",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: title,
					onChange: (event) => setTitle(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Проект",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: inputClass,
					value: projectId,
					onChange: (event) => setProjectId(event.target.value),
					children: [boards.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.name
					}, item.id)), projects.filter((name) => !boards.some((item) => item.name === name)).map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: name,
						children: name
					}, name))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Метки",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: labels.map((label) => {
						const on = picked.includes(label.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setPicked((current) => on ? current.filter((id) => id !== label.id) : [...current, label.id]),
							className: "rounded-full px-3 py-1 text-sm",
							style: {
								background: on ? label.color : "transparent",
								color: on ? "#12110e" : "#f4efe6",
								border: `1px solid ${label.color}`
							},
							children: label.name
						}, label.id);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Важность",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: inputClass,
					value: priority,
					onChange: (event) => setPriority(event.target.value),
					children: PRIORITIES.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: name,
						children: name
					}, name))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Дедлайн",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					type: "date",
					value: deadline,
					onChange: (event) => setDeadline(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Заметка",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: inputClass,
					rows: 3,
					value: description,
					onChange: (event) => setDescription(event.target.value)
				})
			}),
			initial?.created ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-mist",
				children: [
					"Поставлена ",
					formatCreated(initial.created),
					". Это время не меняется."
				]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm text-ember",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-2 w-full rounded-full bg-gold py-3 text-ink",
				onClick: () => {
					if (!title.trim() || !deadline) {
						setError("Нужны текст и дедлайн");
						return;
					}
					onSave({
						title: title.trim(),
						project: board?.name || projectId,
						projectId: board?.id || projectId,
						labelIds: picked,
						priority,
						deadline,
						description
					});
					onClose();
				},
				children: "Сохранить"
			})
		]
	});
}
function formatCreated(iso) {
	if (!iso) return "без даты";
	return new Date(iso).toLocaleString("ru-RU", {
		day: "numeric",
		month: "short",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function formatDeadline(key) {
	if (!key) return "не задан";
	return new Date(dayKeyToDate(key)).toLocaleDateString("ru-RU", {
		day: "numeric",
		month: "short"
	});
}
function dayKeyToDate(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d || 1);
}
var SplitComponent = TasksView;
//#endregion
export { SplitComponent as component };
