import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as streakCount, d as fmtHm, g as spanSeconds, h as shortDay, l as dayKey, m as levelInfo, s as addDays, u as dayScore, v as usePlanner } from "./router-fl6ykAus.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stats-DBLbbeSx.js
var import_jsx_runtime = require_jsx_runtime();
function StatsView() {
	const spans = usePlanner((s) => s.spans);
	const tasks = usePlanner((s) => s.tasks);
	const xp = usePlanner((s) => s.xp);
	const level = levelInfo(xp);
	const today = dayKey();
	const byDay = Array.from({ length: 14 }, (_, index) => addDays(today, index - 13)).map((day) => {
		const seconds = spans.filter((span) => span.day === day).reduce((sum, span) => sum + spanSeconds(span), 0);
		return {
			day: shortDay(day),
			hours: Math.round(seconds / 3600 * 10) / 10
		};
	});
	const todayMap = /* @__PURE__ */ new Map();
	for (const span of spans.filter((span) => span.day === today)) todayMap.set(span.category, (todayMap.get(span.category) ?? 0) + spanSeconds(span));
	const todayRows = [...todayMap.entries()].sort((a, b) => b[1] - a[1]);
	const max = todayRows[0]?.[1] ?? 1;
	const heat = Array.from({ length: 84 }, (_, index) => addDays(today, index - 83));
	const rated = heat.map((day) => dayScore(spans, day)).filter((value) => value != null);
	const avg = rated.length ? (rated.reduce((sum, value) => sum + value, 0) / rated.length).toFixed(1) : "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Как уходит время"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Рост"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Уровень",
						value: String(level.level),
						hint: `${xp} XP`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Серия",
						value: String(streakCount(tasks, spans)),
						hint: "дней"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Средняя оценка",
						value: String(avg),
						hint: "из оценок этапов"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-display text-2xl",
					children: "14 дней, часы"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: byDay,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "day",
									stroke: "var(--color-mist)",
									fontSize: 11,
									tickLine: false,
									axisLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									stroke: "var(--color-mist)",
									fontSize: 11,
									tickLine: false,
									axisLine: false,
									width: 28
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "var(--color-panel-2)" },
									contentStyle: {
										background: "var(--color-panel-2)",
										border: "1px solid var(--color-line)",
										borderRadius: 12
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "hours",
									fill: "var(--color-gold)",
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 font-display text-2xl",
						children: "Сегодня по категориям"
					}),
					todayRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-mist",
						children: "Тайминг за сегодня ещё не начат."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3",
						children: todayRows.map(([name, seconds]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gold",
								children: fmtHm(seconds)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-3 overflow-hidden rounded-full bg-panel-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-gold",
								style: { width: `${seconds / max * 100}%` }
							})
						})] }, name))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-display text-2xl",
					children: "12 недель"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-12 gap-1",
					children: heat.map((day) => {
						const seconds = spans.filter((span) => span.day === day).reduce((sum, span) => sum + spanSeconds(span), 0);
						const hours = seconds / 3600;
						const alpha = hours === 0 ? .08 : Math.min(1, .25 + hours / 8);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							title: `${day} · ${fmtHm(seconds)}`,
							className: "aspect-square rounded-sm bg-gold",
							style: { opacity: alpha }
						}, day);
					})
				})]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: hint
			})
		]
	});
}
var SplitComponent = StatsView;
//#endregion
export { SplitComponent as component };
