import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desktop-download-CQnZm49J.js
var import_jsx_runtime = require_jsx_runtime();
function DesktopDownload() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: "/downloads/ToDO-AKA-windows.zip",
		download: "ToDO-AKA-windows.zip",
		className: "my-4 flex items-center justify-between gap-3 rounded-card border border-line bg-panel p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block font-display text-2xl",
			children: "Программа для Windows"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm text-mist",
			children: "Тот же экран, что на сайте: задачи, кольца, помидор и тайминг. Распакуй архив и открой ToDO-AKA.exe."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 rounded-full bg-gold px-4 py-2 text-sm text-ink",
			children: "Скачать"
		})]
	});
}
//#endregion
export { DesktopDownload as t };
