import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { $t as unknown, Gt as literal, Ht as array, Jt as object, Qt as union, Ut as boolean, Zt as string, qt as number } from "../_libs/@better-auth/core+[...].mjs";
import { t as authMiddleware } from "./middleware-CO7pgAcK.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as TriangleAlert, c as ListChecks, d as Ellipsis, f as ChartColumn, i as UserRound, n as VolumeX, o as Timer, r as Volume2, s as Sun, u as Flag } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-b1CclOdV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function dayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function addDays(key, delta) {
	const [y, m, d] = key.split("-").map(Number);
	const date = new Date(y, m - 1, d);
	date.setDate(date.getDate() + delta);
	return dayKey(date);
}
function formatDay(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("ru-RU", {
		day: "numeric",
		month: "long",
		weekday: "long"
	});
}
function shortDay(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("ru-RU", {
		day: "2-digit",
		month: "2-digit"
	});
}
function clock(iso) {
	return new Date(iso).toLocaleTimeString("ru-RU", {
		hour: "2-digit",
		minute: "2-digit"
	});
}
function fmtSpan(seconds) {
	const s = Math.max(0, Math.floor(seconds));
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}
function fmtHm(seconds) {
	const total = Math.round(Math.max(0, seconds) / 60);
	const h = Math.floor(total / 60);
	const m = total % 60;
	return `${h}:${String(m).padStart(2, "0")}`;
}
function endOfDayMs(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, m - 1, d, 23, 59, 59, 999).getTime();
}
var COLORS = [
	"#e8a317",
	"#ef5d32",
	"#7aa2f7",
	"#8fbf6a",
	"#c58af9",
	"#f2a2c0"
];
function makeBoards(names) {
	return [{
		id: "inbox",
		name: "Входящие",
		color: "#e8a317",
		inbox: true
	}, ...names.filter((name) => name !== "Входящие").map((name, index) => ({
		id: `project-${index}-${name}`,
		name,
		color: COLORS[index % COLORS.length] ?? "#e8a317",
		inbox: false
	}))];
}
var LABELS = [
	{
		id: "call",
		name: "Звонок",
		color: "#ef5d32"
	},
	{
		id: "idea",
		name: "Идея",
		color: "#e8a317"
	},
	{
		id: "home",
		name: "Дом",
		color: "#8fbf6a"
	},
	{
		id: "wait",
		name: "Ждёт",
		color: "#7aa2f7"
	}
];
var PROJECTS = [
	"Работа / Бизнес",
	"Финансы",
	"Здоровье",
	"Семья",
	"Обучение",
	"Дом",
	"Блог",
	"Электрика",
	"Прочее"
];
var TIME = [
	"Работа",
	"Сон",
	"Еда",
	"Спорт",
	"Чтение",
	"Планирование",
	"Соцсети",
	"Отдых",
	"Дорога",
	"Здоровье",
	"Финансы",
	"Программирование",
	"Электрика",
	"Общение",
	"Йога",
	"Покер",
	"Сбор",
	"Уборка",
	"Философия"
];
var uid = () => crypto.randomUUID();
function levelInfo(xp) {
	let level = 1;
	let rest = xp;
	let need = 80;
	while (rest >= need) {
		rest -= need;
		level += 1;
		need = 60 + level * 20;
	}
	return {
		level,
		into: rest,
		need
	};
}
function dayScore(spans, day) {
	const rated = spans.filter((span) => span.day === day && span.end && span.score);
	if (rated.length === 0) return null;
	const sum = rated.reduce((total, span) => total + (span.score ?? 0), 0);
	return Math.round(sum / rated.length * 10) / 10;
}
function spanSeconds(span, now = Date.now()) {
	const start = new Date(span.start).getTime();
	const cap = span.end ? new Date(span.end).getTime() : Math.min(now, endOfDayMs(span.day));
	return Math.max(0, (cap - start) / 1e3);
}
function streakCount(tasks, spans) {
	const days = /* @__PURE__ */ new Set();
	for (const task of tasks) if (task.completed) days.add(task.completed.slice(0, 10));
	for (const span of spans) days.add(span.day);
	let cursor = dayKey();
	if (!days.has(cursor)) cursor = shift(cursor, -1);
	let n = 0;
	while (days.has(cursor)) {
		n += 1;
		cursor = shift(cursor, -1);
	}
	return n;
}
function shift(key, delta) {
	const [y, m, d] = key.split("-").map(Number);
	const date = new Date(y, (m ?? 1) - 1, d);
	date.setDate(date.getDate() + delta);
	return dayKey(date);
}
var emptyPomo = () => ({
	running: false,
	mode: "focus",
	endsAt: 0,
	remaining: 1500,
	taskId: "",
	minutes: 25
});
var usePlanner = create()(persist((set, get) => ({
	mission: "Стать лучшей версией себя: хитрым, мудрым, живучим, успешным. Превращать хаос в порядок — в себе, в других и в мире.",
	xp: 0,
	sound: true,
	projects: PROJECTS,
	boards: makeBoards(PROJECTS),
	labels: LABELS,
	timeCats: TIME,
	tasks: [],
	spans: [],
	goals: [{
		id: "mission-goal",
		title: "Финансовая свобода",
		content: "Чистая прибыль 300 000 ₽ в месяц. Капитал 10 млн. Пассив 100 000 ₽."
	}],
	contacts: [],
	ideas: [],
	books: [],
	scores: {},
	pomo: emptyPomo(),
	reward: null,
	undo: null,
	burst: 0,
	setMission: (mission) => set({ mission }),
	toggleSound: () => set({ sound: !get().sound }),
	addTask: (task) => {
		const board = get().boards.find((item) => item.id === task.projectId) || get().boards.find((item) => item.name === task.project) || get().boards.find((item) => item.inbox);
		set({ tasks: [{
			id: uid(),
			created: (/* @__PURE__ */ new Date()).toISOString(),
			completed: "",
			pomodoros: 0,
			status: task.status ?? "В ожидании",
			labelIds: task.labelIds ?? [],
			...task,
			projectId: board?.id ?? "inbox",
			project: board?.name ?? task.project
		}, ...get().tasks] });
	},
	updateTask: (id, patch) => set({ tasks: get().tasks.map((t) => t.id === id ? {
		...t,
		...patch
	} : t) }),
	completeTask: (id) => {
		const task = get().tasks.find((t) => t.id === id);
		if (!task) return;
		if (task.status === "Выполнено") {
			set({
				undo: null,
				xp: Math.max(0, get().xp - 15),
				tasks: get().tasks.map((t) => t.id === id ? {
					...t,
					status: t.beforeStatus || "В ожидании",
					completed: "",
					beforeStatus: void 0
				} : t)
			});
			return;
		}
		const gained = award(get().xp, 15, "Задача закрыта");
		set({
			tasks: get().tasks.map((t) => t.id === id ? {
				...t,
				status: "Выполнено",
				beforeStatus: t.status,
				completed: (/* @__PURE__ */ new Date()).toISOString()
			} : t),
			undo: {
				id,
				title: task.title,
				at: Date.now()
			},
			...gained,
			burst: get().burst + 1
		});
	},
	dismissUndo: () => set({ undo: null }),
	deleteTask: (id) => set({ tasks: get().tasks.filter((t) => t.id !== id) }),
	startSpan: (category, at) => {
		const moment = at ? new Date(at) : /* @__PURE__ */ new Date();
		const day = dayKey(moment);
		const iso = moment.toISOString();
		let spans = get().spans.map((span) => ({ ...span }));
		const open = spans.find((span) => span.day === day && !span.end);
		if (open && open.category === category && !at) return;
		if (open) {
			if (moment.getTime() <= new Date(open.start).getTime()) return;
			open.end = iso;
		}
		const firstToday = !spans.some((span) => span.day === day);
		spans = [...spans, {
			id: uid(),
			day,
			category,
			start: iso,
			end: ""
		}];
		const gained = open ? award(get().xp, 3, "Этап закрыт") : firstToday ? award(get().xp, 5, "День начат") : {};
		set({
			spans,
			...gained,
			...open || firstToday ? { burst: get().burst + 1 } : {}
		});
	},
	stopSpan: (day, at) => {
		const moment = at ? new Date(at) : /* @__PURE__ */ new Date();
		let closed = false;
		set({
			spans: get().spans.map((span) => {
				if (span.day !== day || span.end) return span;
				if (moment.getTime() <= new Date(span.start).getTime()) return span;
				closed = true;
				return {
					...span,
					end: moment.toISOString()
				};
			}),
			...closed ? award(get().xp, 3, "Этап закрыт") : {},
			...closed ? { burst: get().burst + 1 } : {}
		});
	},
	updateSpan: (id, patch) => {
		const prev = get().spans.find((span) => span.id === id);
		const spans = get().spans.map((span) => span.id === id ? {
			...span,
			...patch
		} : span);
		const scored = typeof patch.score === "number" && prev && prev.score !== patch.score;
		set({
			spans,
			...scored ? award(get().xp, 2, `Оценка ${patch.score}`) : {},
			...scored ? { burst: get().burst + 1 } : {}
		});
	},
	deleteSpan: (id) => set({ spans: get().spans.filter((span) => span.id !== id) }),
	addManualSpan: (category, day, start, end) => set({ spans: [...get().spans, {
		id: uid(),
		day,
		category,
		start,
		end
	}] }),
	setScore: (day, score) => set({ scores: {
		...get().scores,
		[day]: score
	} }),
	addGoal: (title) => set({ goals: [...get().goals, {
		id: uid(),
		title,
		content: ""
	}] }),
	updateGoal: (id, content) => set({ goals: get().goals.map((g) => g.id === id ? {
		...g,
		content
	} : g) }),
	deleteGoal: (id) => set({ goals: get().goals.filter((g) => g.id !== id) }),
	renameCategory: (kind, from, to) => {
		const clean = to.trim();
		if (!clean || clean === from) return;
		if (kind === "project") set({
			projects: get().projects.map((name) => name === from ? clean : name),
			boards: get().boards.map((board) => board.name === from ? {
				...board,
				name: clean
			} : board),
			tasks: get().tasks.map((task) => task.project === from ? {
				...task,
				project: clean
			} : task)
		});
		else set({
			timeCats: get().timeCats.map((name) => name === from ? clean : name),
			spans: get().spans.map((span) => span.category === from ? {
				...span,
				category: clean
			} : span)
		});
	},
	addCategory: (kind, name) => {
		const clean = name.trim();
		if (!clean) return;
		if (kind === "project") {
			if (get().projects.includes(clean) || get().boards.some((board) => board.name === clean)) return;
			const board = {
				id: uid(),
				name: clean,
				color: COLORS[get().boards.length % COLORS.length] ?? "#e8a317",
				inbox: false
			};
			set({
				projects: [...get().projects, clean].sort((a, b) => a.localeCompare(b, "ru")),
				boards: [...get().boards, board]
			});
		} else {
			if (get().timeCats.includes(clean)) return;
			set({ timeCats: [...get().timeCats, clean].sort((a, b) => a.localeCompare(b, "ru")) });
		}
	},
	deleteCategory: (kind, name) => {
		if (kind === "project") set({
			projects: get().projects.filter((item) => item !== name),
			boards: get().boards.filter((board) => board.inbox || board.name !== name)
		});
		else set({ timeCats: get().timeCats.filter((item) => item !== name) });
	},
	addLabel: (name) => {
		const clean = name.trim();
		if (!clean || get().labels.some((label) => label.name === clean)) return;
		set({ labels: [...get().labels, {
			id: uid(),
			name: clean,
			color: COLORS[get().labels.length % COLORS.length] ?? "#e8a317"
		}] });
	},
	deleteLabel: (id) => set({
		labels: get().labels.filter((label) => label.id !== id),
		tasks: get().tasks.map((task) => ({
			...task,
			labelIds: (task.labelIds ?? []).filter((labelId) => labelId !== id)
		}))
	}),
	addContact: (contact) => set({ contacts: [...get().contacts, {
		...contact,
		id: uid()
	}] }),
	addIdea: (idea) => set({ ideas: [{
		...idea,
		id: uid()
	}, ...get().ideas] }),
	addBook: (book) => set({ books: [{
		...book,
		id: uid(),
		date: dayKey()
	}, ...get().books] }),
	startPomo: (minutes, taskId = "", mode = "focus") => set({ pomo: {
		running: true,
		mode,
		minutes,
		remaining: minutes * 60,
		endsAt: Date.now() + minutes * 60 * 1e3,
		taskId
	} }),
	pausePomo: () => {
		const pomo = get().pomo;
		if (!pomo.running) {
			set({ pomo: {
				...pomo,
				running: true,
				endsAt: Date.now() + pomo.remaining * 1e3
			} });
			return;
		}
		const remaining = Math.max(0, Math.round((pomo.endsAt - Date.now()) / 1e3));
		set({ pomo: {
			...pomo,
			running: false,
			remaining,
			endsAt: 0
		} });
	},
	stopPomo: () => set({ pomo: emptyPomo() }),
	finishPomo: () => {
		const pomo = get().pomo;
		if (pomo.mode === "break") {
			set({ pomo: emptyPomo() });
			return;
		}
		const taskId = pomo.taskId;
		const gained = award(get().xp, 10, "Помидор закрыт");
		set({
			pomo: {
				...emptyPomo(),
				mode: "break",
				remaining: 300,
				minutes: 5,
				taskId,
				running: false
			},
			tasks: get().tasks.map((task) => task.id === taskId ? {
				...task,
				pomodoros: task.pomodoros + 1
			} : task),
			...gained,
			burst: get().burst + 1
		});
	},
	clearReward: () => set({ reward: null })
}), {
	name: "poryadok-v1",
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		const projects = saved.projects?.length ? saved.projects : current.projects;
		return {
			...current,
			...saved,
			projects,
			boards: saved.boards?.length ? saved.boards : makeBoards(projects),
			labels: saved.labels?.length ? saved.labels : current.labels,
			burst: 0,
			reward: null,
			undo: null
		};
	}
}));
function award(xp, amount, text) {
	const before = levelInfo(xp).level;
	const next = xp + amount;
	return {
		xp: next,
		reward: {
			id: uid(),
			amount,
			text,
			levelUp: levelInfo(next).level > before
		}
	};
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-fl6ykAus.js
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Burst({ nonce }) {
	const ref = (0, import_react.useRef)(null);
	const bits = (0, import_react.useRef)([]);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let frame = 0;
		const resize = () => {
			canvas.width = window.innerWidth;
			canvas.height = window.innerHeight;
		};
		resize();
		window.addEventListener("resize", resize);
		const tick = () => {
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			bits.current = bits.current.filter((bit) => bit.life > 0);
			for (const bit of bits.current) {
				bit.x += bit.vx;
				bit.y += bit.vy;
				bit.vy += .12;
				bit.life -= .012;
				ctx.globalAlpha = Math.max(0, bit.life);
				ctx.fillStyle = bit.color;
				ctx.fillRect(bit.x, bit.y, bit.w, bit.w * .55);
			}
			ctx.globalAlpha = 1;
			frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => {
			cancelAnimationFrame(frame);
			window.removeEventListener("resize", resize);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!nonce) return;
		const canvas = ref.current;
		if (!canvas) return;
		const colors = [
			"#e8a317",
			"#f6d27a",
			"#ef5d32",
			"#f4efe6"
		];
		const cx = canvas.width * .5;
		const cy = canvas.height * .38;
		for (let i = 0; i < 140; i += 1) {
			const angle = Math.PI * 2 * i / 140 + Math.random();
			const speed = 4 + Math.random() * 9;
			bits.current.push({
				x: cx,
				y: cy,
				vx: Math.cos(angle) * speed,
				vy: Math.sin(angle) * speed - 3,
				life: 1,
				color: colors[i % colors.length] ?? "#e8a317",
				w: 7 + Math.random() * 8
			});
		}
	}, [nonce]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "pointer-events-none fixed inset-0 z-40",
		"aria-hidden": "true"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var ctx = null;
var enabled = true;
function setSoundEnabled(value) {
	enabled = value;
}
function ac() {
	if (typeof window === "undefined") return null;
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return null;
	if (!ctx) ctx = new Ctx();
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function tone(freq, dur, type, gain, delay = 0) {
	if (!enabled) return;
	const audio = ac();
	if (!audio) return;
	const t = audio.currentTime + delay;
	const osc = audio.createOscillator();
	const amp = audio.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, t);
	amp.gain.setValueAtTime(1e-4, t);
	amp.gain.exponentialRampToValueAtTime(gain, t + .02);
	amp.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	osc.connect(amp);
	amp.connect(audio.destination);
	osc.start(t);
	osc.stop(t + dur + .02);
}
function playTap() {
	tone(640, .05, "sine", .04);
}
function playStart() {
	tone(392, .09, "triangle", .05);
	tone(587, .12, "triangle", .045, .07);
}
function playStop() {
	tone(349, .08, "sine", .04);
	tone(262, .12, "sine", .035, .06);
}
function playWin() {
	[
		523,
		659,
		784,
		1046
	].forEach((f, i) => tone(f, .18, "sine", .06, i * .08));
}
function playXp() {
	tone(880, .07, "triangle", .04);
	tone(1174, .12, "triangle", .04, .06);
}
function playBell() {
	tone(784, .45, "sine", .07);
	tone(1174, .55, "triangle", .035, .02);
}
function playLevel() {
	[
		523,
		659,
		784,
		1046,
		1318
	].forEach((f, i) => tone(f, .22, "sine", .06, i * .09));
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var changeSchema = object({
	collection: string().max(40),
	id: string().max(80),
	updatedAt: number().int(),
	deleted: boolean(),
	payload: unknown()
});
var bodySchema = object({
	since: number().int().nonnegative(),
	changes: array(changeSchema).max(2e3)
});
var pushPull = createServerFn({ method: "POST" }).middleware([authMiddleware]).inputValidator(bodySchema).handler(createSsrRpc("29449fcaa9124460b3680cfd58a9430b91e7fbafebef68cb829855cc2472ebfb"));
var LISTS = [
	"tasks",
	"spans",
	"goals",
	"contacts",
	"ideas",
	"books",
	"boards",
	"labels"
];
var SENT_KEY = "poryadok-sync-sent";
var CURSOR_KEY = "poryadok-sync-cursor";
var status = "local";
var lastError = "";
var listeners = /* @__PURE__ */ new Set();
var timer = 0;
var running = false;
var started = false;
function emit(next, error = "") {
	status = next;
	lastError = error;
	listeners.forEach((listener) => listener());
}
function useSyncStatus() {
	return {
		status: (0, import_react.useSyncExternalStore)((listener) => {
			listeners.add(listener);
			return () => listeners.delete(listener);
		}, () => status, () => "local"),
		error: lastError
	};
}
function loadSent() {
	try {
		return JSON.parse(localStorage.getItem(SENT_KEY) || "{}");
	} catch {
		return {};
	}
}
function saveSent(sent) {
	localStorage.setItem(SENT_KEY, JSON.stringify(sent));
}
function snapshot(state) {
	const map = /* @__PURE__ */ new Map();
	for (const collection of LISTS) for (const item of state[collection]) {
		if (!item?.id) continue;
		map.set(`${collection}:${item.id}`, {
			collection,
			id: item.id,
			payload: item
		});
	}
	map.set("meta:profile", {
		collection: "meta",
		id: "profile",
		payload: {
			mission: state.mission,
			xp: state.xp,
			scores: state.scores,
			timeCats: state.timeCats,
			projects: state.projects
		}
	});
	return map;
}
function changesSince(sent, state) {
	const now = Date.now();
	const current = snapshot(state);
	const changes = [];
	for (const [key, row] of current) {
		const json = JSON.stringify(row.payload);
		if (sent[key] !== json) {
			changes.push({
				collection: row.collection,
				id: row.id,
				updatedAt: now,
				deleted: false,
				payload: row.payload
			});
			sent[key] = json;
		}
	}
	for (const key of Object.keys(sent)) if (!current.has(key) && sent[key] !== "deleted") {
		const [collection, id] = key.split(":");
		changes.push({
			collection,
			id,
			updatedAt: now,
			deleted: true,
			payload: {}
		});
		sent[key] = "deleted";
	}
	return changes;
}
function applyRecords(records) {
	if (!records.length) return;
	const sent = loadSent();
	usePlanner.setState((state) => {
		const next = { ...state };
		const lists = Object.fromEntries(LISTS.map((name) => [name, [...state[name]]]));
		for (const record of records) {
			const key = `${record.collection}:${record.id}`;
			if (record.collection === "meta" && record.id === "profile" && !record.deleted) {
				const payload = record.payload;
				next.mission = payload.mission;
				next.xp = payload.xp;
				next.scores = payload.scores;
				next.timeCats = payload.timeCats;
				next.projects = payload.projects;
				sent[key] = JSON.stringify(payload);
				continue;
			}
			if (!LISTS.includes(record.collection)) continue;
			const list = lists[record.collection];
			const index = list.findIndex((item) => item.id === record.id);
			if (record.deleted) {
				if (index >= 0) list.splice(index, 1);
				sent[key] = "deleted";
			} else {
				const payload = record.payload;
				if (index >= 0) list[index] = payload;
				else list.unshift(payload);
				sent[key] = JSON.stringify(payload);
			}
		}
		saveSent(sent);
		return {
			...next,
			...lists
		};
	});
}
async function syncNow() {
	if (typeof window === "undefined" || running) return;
	if (!navigator.onLine) {
		emit("offline");
		return;
	}
	running = true;
	emit("sync");
	try {
		const sent = loadSent();
		const changes = changesSince(sent, usePlanner.getState());
		const since = Number(localStorage.getItem(CURSOR_KEY) || 0);
		const result = await pushPull({ data: {
			since,
			changes
		} });
		saveSent(sent);
		applyRecords(result.records);
		const newest = result.records.reduce((max, row) => Math.max(max, row.updatedAt), since);
		localStorage.setItem(CURSOR_KEY, String(newest));
	} catch {
		emit(navigator.onLine ? "local" : "offline", "нет связи с сервером");
	} finally {
		running = false;
	}
}
function startSync() {
	if (started || typeof window === "undefined") return;
	started = true;
	usePlanner.subscribe(() => {
		window.clearTimeout(timer);
		timer = window.setTimeout(() => void syncNow(), 1200);
	});
	window.addEventListener("online", () => void syncNow());
	window.addEventListener("offline", () => emit("offline"));
	if (!navigator.onLine) emit("offline");
	syncNow();
}
var NAV = [
	{
		to: "/",
		label: "Сегодня",
		icon: Sun
	},
	{
		to: "/tasks",
		label: "Задачи",
		icon: ListChecks
	},
	{
		to: "/timing",
		label: "Тайминг",
		icon: Timer
	},
	{
		to: "/stats",
		label: "Рост",
		icon: ChartColumn
	},
	{
		to: "/goals",
		label: "Цели",
		icon: Flag
	},
	{
		to: "/more",
		label: "Ещё",
		icon: Ellipsis
	},
	{
		to: "/account",
		label: "Кабинет",
		icon: UserRound
	}
];
function Shell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ready, { children });
}
function Ready({ children }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	const sound = usePlanner((s) => s.sound);
	const toggleSound = usePlanner((s) => s.toggleSound);
	const reward = usePlanner((s) => s.reward);
	const clearReward = usePlanner((s) => s.clearReward);
	const undo = usePlanner((s) => s.undo);
	const dismissUndo = usePlanner((s) => s.dismissUndo);
	const completeTask = usePlanner((s) => s.completeTask);
	const burst = usePlanner((s) => s.burst);
	const pomo = usePlanner((s) => s.pomo);
	const pausePomo = usePlanner((s) => s.pausePomo);
	const stopPomo = usePlanner((s) => s.stopPomo);
	const finishPomo = usePlanner((s) => s.finishPomo);
	const { status } = useSyncStatus();
	const [now, setNow] = (0, import_react.useState)(Date.now());
	(0, import_react.useEffect)(() => {
		startSync();
		if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js");
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => setSoundEnabled(sound), [sound]);
	(0, import_react.useEffect)(() => {
		if (!undo) return;
		const timer = window.setTimeout(dismissUndo, 6e3);
		return () => window.clearTimeout(timer);
	}, [undo, dismissUndo]);
	(0, import_react.useEffect)(() => {
		if (!reward) return;
		if (reward.levelUp) playLevel();
		else if (reward.amount >= 15) playWin();
		else playXp();
		const timer = window.setTimeout(clearReward, 1200);
		return () => window.clearTimeout(timer);
	}, [reward, clearReward]);
	(0, import_react.useEffect)(() => {
		if (!pomo.running || !pomo.endsAt) return;
		const timer = window.setInterval(() => {
			const current = usePlanner.getState().pomo;
			if (current.running && current.endsAt && Date.now() >= current.endsAt) {
				playBell();
				finishPomo();
			}
		}, 250);
		return () => window.clearInterval(timer);
	}, [
		pomo.running,
		pomo.endsAt,
		finishPomo
	]);
	const left = pomo.running ? Math.max(0, Math.round((pomo.endsAt - now) / 1e3)) : pomo.remaining;
	const showDock = pomo.running || pomo.remaining > 0 && pomo.remaining !== pomo.minutes * 60;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-ink font-sans text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-20 hidden w-24 flex-col items-center gap-2 border-r border-line bg-panel py-5 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "mb-4 font-display text-lg text-gold",
						children: "AKA"
					}),
					NAV.map((item) => {
						const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex w-[4.5rem] flex-col items-center gap-1 rounded-2xl px-1 py-2 text-[11px]", active ? "bg-gold text-ink" : "text-mist"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}, item.to);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggleSound,
						className: "mt-auto text-mist hover:text-cream",
						"aria-label": "Звук",
						children: sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto min-h-screen max-w-5xl px-4 pt-6 pb-28 md:pl-32 md:pr-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 font-display text-2xl text-gold",
						children: "ToDO-AKA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-xs text-mist",
						children: syncLabel(status)
					}),
					children
				]
			}),
			showDock ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed right-4 bottom-24 z-30 flex items-center gap-3 rounded-card border border-gold bg-panel px-4 py-3 md:bottom-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide text-gold uppercase",
						children: pomo.mode === "break" ? "Перерыв" : "Помидор"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: fmtSpan(left)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: pausePomo,
						className: "rounded-full bg-panel-2 px-3 py-2 text-sm",
						children: pomo.running ? "Пауза" : "Дальше"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: stopPomo,
						className: "rounded-full bg-ember px-3 py-2 text-sm text-ink",
						children: "Стоп"
					})
				]
			}) : null,
			undo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed bottom-24 left-1/2 z-40 flex max-w-[90vw] -translate-x-1/2 items-center gap-3 rounded-full border border-line bg-panel px-4 py-2 md:bottom-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "truncate text-sm",
					children: ["Готово · ", undo.title]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "shrink-0 text-gold",
					onClick: () => completeTask(undo.id),
					children: "Отменить"
				})]
			}) : null,
			reward ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed top-20 left-1/2 z-50 animate-[rise_1100ms_ease-out_forwards]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-full bg-gold px-5 py-2 font-display text-xl text-ink",
					children: [
						"+",
						reward.amount,
						" XP · ",
						reward.levelUp ? "Новый уровень" : reward.text
					]
				})
			}) : null,
			burst > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Burst, { nonce: burst }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 flex border-t border-line bg-panel md:hidden",
				children: NAV.filter((item) => item.to !== "/goals").map((item) => {
					const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("flex flex-1 flex-col items-center gap-1 py-2 text-[10px]", active ? "text-gold" : "text-mist"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
					}, item.to);
				})
			})
		]
	});
}
function syncLabel(status) {
	if (status === "offline") return "Офлайн · данные на этом устройстве";
	if (status === "sync") return "Синхронизация…";
	if (status === "ok") return "Синхронизировано";
	return "Локально · синхронизация при входе";
}
var styles_default = "/assets/styles-Cgm4Tafz.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ToDO-AKA" },
			{
				name: "theme-color",
				content: "#12110e"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: "/fonts/fonts.css"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$6 = () => import("./routes-J5RDtpYb.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./account-B_9vAdBh.mjs");
var Route$5 = createFileRoute("/account")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./goals-D5ms5zbE.mjs");
var Route$4 = createFileRoute("/goals")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./more-DGw2s1T2.mjs");
var Route$3 = createFileRoute("/more")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./stats-DBLbbeSx.mjs");
var Route$2 = createFileRoute("/stats")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./tasks-BhMM34us.mjs");
var Route$1 = createFileRoute("/tasks")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./timing-e0Gh1s_Y.mjs");
var Route = createFileRoute("/timing")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	AccountRoute: Route$5.update({
		id: "/account",
		path: "/account",
		getParentRoute: () => Route$7
	}),
	GoalsRoute: Route$4.update({
		id: "/goals",
		path: "/goals",
		getParentRoute: () => Route$7
	}),
	MoreRoute: Route$3.update({
		id: "/more",
		path: "/more",
		getParentRoute: () => Route$7
	}),
	StatsRoute: Route$2.update({
		id: "/stats",
		path: "/stats",
		getParentRoute: () => Route$7
	}),
	TasksRoute: Route$1.update({
		id: "/tasks",
		path: "/tasks",
		getParentRoute: () => Route$7
	}),
	TimingRoute: Route.update({
		id: "/timing",
		path: "/timing",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { streakCount as _, playStop as a, clock as c, fmtHm as d, fmtSpan as f, spanSeconds as g, shortDay as h, playStart as i, dayKey as l, levelInfo as m, syncNow as n, playTap as o, formatDay as p, useSyncStatus as r, addDays as s, router_exports as t, dayScore as u, usePlanner as v };
