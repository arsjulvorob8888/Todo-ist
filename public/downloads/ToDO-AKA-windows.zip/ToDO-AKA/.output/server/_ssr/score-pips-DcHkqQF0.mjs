import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/score-pips-DcHkqQF0.js
var import_jsx_runtime = require_jsx_runtime();
function ScorePips({ value, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1",
		children: Array.from({ length: 10 }, (_, index) => index + 1).map((score) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": `Оценка ${score}`,
			onClick: () => onPick(score),
			className: `size-7 rounded-full text-xs ${value === score ? "bg-gold text-ink" : "bg-panel-2 text-mist"}`,
			children: score
		}, score))
	});
}
//#endregion
export { ScorePips as t };
