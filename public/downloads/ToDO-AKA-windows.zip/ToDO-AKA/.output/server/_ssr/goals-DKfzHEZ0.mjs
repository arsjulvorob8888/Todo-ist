import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as usePlanner } from "./router-Dr7Ztepa.mjs";
import { n as Modal, r as inputClass, t as Field } from "./modal-B9fcrG3Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/goals-DKfzHEZ0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GoalsView() {
	const mission = usePlanner((s) => s.mission);
	const setMission = usePlanner((s) => s.setMission);
	const goals = usePlanner((s) => s.goals);
	const addGoal = usePlanner((s) => s.addGoal);
	const updateGoal = usePlanner((s) => s.updateGoal);
	const deleteGoal = usePlanner((s) => s.deleteGoal);
	const [draft, setDraft] = (0, import_react.useState)(mission);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Зачем всё это"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Цели"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Миссия"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${inputClass} mt-3`,
						rows: 5,
						value: draft,
						onChange: (event) => setDraft(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 rounded-full bg-gold px-4 py-2 text-ink",
						onClick: () => setMission(draft),
						children: "Сохранить миссию"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Глобальные цели"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-panel px-4 py-2",
					onClick: () => setOpen(true),
					children: "Добавить"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: goals.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-card border border-line bg-panel p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl",
							children: goal.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm text-ember",
							onClick: () => deleteGoal(goal.id),
							children: "Удалить"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: inputClass,
						rows: 3,
						defaultValue: goal.content,
						onBlur: (event) => updateGoal(goal.id, event.target.value)
					})]
				}, goal.id))
			})] }),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				title: "Новая цель",
				onClose: () => setOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Название",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: title,
						onChange: (event) => setTitle(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "w-full rounded-full bg-gold py-3 text-ink",
					onClick: () => {
						if (!title.trim()) return;
						addGoal(title.trim());
						setTitle("");
						setOpen(false);
					},
					children: "Сохранить"
				})]
			}) : null
		]
	});
}
var SplitComponent = GoalsView;
//#endregion
export { SplitComponent as component };
