import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as playStop, c as clock, d as fmtHm, f as fmtSpan, g as spanSeconds, i as playStart, l as dayKey, o as playTap, p as formatDay, s as addDays, u as dayScore, v as usePlanner } from "./router-aju2iEXR.mjs";
import { n as Modal, r as inputClass, t as Field } from "./modal-B9fcrG3Z.mjs";
import { t as ScorePips } from "./score-pips-DcHkqQF0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/timing-DqkfN7cV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TimingView() {
	const timeCats = usePlanner((s) => s.timeCats);
	const spans = usePlanner((s) => s.spans);
	const startSpan = usePlanner((s) => s.startSpan);
	const stopSpan = usePlanner((s) => s.stopSpan);
	const deleteSpan = usePlanner((s) => s.deleteSpan);
	const updateSpan = usePlanner((s) => s.updateSpan);
	const addManualSpan = usePlanner((s) => s.addManualSpan);
	const [day, setDay] = (0, import_react.useState)(dayKey());
	const [manual, setManual] = (0, import_react.useState)(false);
	const [ask, setAsk] = (0, import_react.useState)(null);
	const [askTime, setAskTime] = (0, import_react.useState)("12:00");
	const [, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setTick((n) => n + 1), 1e3);
		return () => window.clearInterval(id);
	}, []);
	const daySpans = spans.filter((span) => span.day === day).sort((a, b) => a.start.localeCompare(b.start));
	const open = daySpans.find((span) => !span.end);
	const totals = /* @__PURE__ */ new Map();
	for (const span of daySpans) totals.set(span.category, (totals.get(span.category) ?? 0) + spanSeconds(span));
	const grand = [...totals.values()].reduce((sum, value) => sum + value, 0);
	const score = dayScore(spans, day);
	const ratedCount = daySpans.filter((span) => span.end && span.score).length;
	function begin(category) {
		if (day !== dayKey()) {
			setAskTime("12:00");
			setAsk({
				category,
				mode: "start"
			});
			return;
		}
		playStart();
		startSpan(category);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-4 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Лента дня"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl capitalize",
				children: formatDay(day)
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-full bg-panel px-3 py-2",
						onClick: () => setDay(addDays(day, -1)),
						children: "Назад"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-full bg-panel px-3 py-2",
						onClick: () => setDay(dayKey()),
						children: "Сегодня"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-full bg-panel px-3 py-2",
						onClick: () => setDay(addDays(day, 1)),
						children: "Вперёд"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mb-4 rounded-card border border-line bg-panel p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl",
					children: open ? `${open.category} · ${fmtSpan(spanSeconds(open))}` : "Пауза"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: "Нажатие категории ставит старт и закрывает предыдущую."
				}),
				open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 rounded-full bg-ember px-4 py-2 text-ink",
					onClick: () => {
						if (day !== dayKey()) {
							setAskTime("18:00");
							setAsk({
								category: open.category,
								mode: "stop"
							});
							return;
						}
						playStop();
						stopSpan(day);
					},
					children: "Стоп"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: timeCats.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => begin(name),
						className: `rounded-full px-3 py-2 text-sm ${open?.category === name ? "bg-gold text-ink" : "bg-panel-2"}`,
						children: name
					}, name))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "md:col-span-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Интервалы"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-gold",
						onClick: () => setManual(true),
						children: "Вручную"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2",
					children: [daySpans.map((span) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-panel px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "w-28 text-sm text-mist",
									children: [
										clock(span.start),
										" – ",
										span.end ? clock(span.end) : "идёт"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1",
									children: span.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: fmtSpan(spanSeconds(span))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-sm text-ember",
									onClick: () => {
										playTap();
										deleteSpan(span.id);
									},
									children: "Удалить"
								})
							]
						}), span.end ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorePips, {
								value: span.score,
								onPick: (value) => updateSpan(span.id, { score: value })
							})
						}) : null]
					}, span.id)), daySpans.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-mist",
						children: "За этот день ещё пусто."
					}) : null]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-card border border-line bg-panel p-4 md:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Итого"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: [...totals.entries()].sort((a, b) => b[1] - a[1]).map(([name, seconds]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmtHm(seconds) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 overflow-hidden rounded-full bg-panel-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-gold",
								style: { width: `${grand ? seconds / grand * 100 : 0}%` }
							})
						})] }, name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 font-display text-xl",
						children: ["Всего ", fmtHm(grand)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-mist",
						children: [
							"Оценка дня",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block font-display text-3xl text-cream",
								children: score ?? "—"
							}),
							score != null ? `Среднее из ${ratedCount} этапов` : "Поставь оценку каждому закрытому этапу"
						]
					})
				]
			})]
		}),
		ask ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: ask.mode === "start" ? "Начало" : "Окончание",
			onClose: () => setAsk(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Время, часы и минуты",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: askTime,
					onChange: (event) => setAskTime(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "w-full rounded-full bg-gold py-3 text-ink",
				onClick: () => {
					const iso = combine(day, askTime);
					if (!iso) return;
					if (ask.mode === "start") startSpan(ask.category, iso);
					else stopSpan(day, iso);
					setAsk(null);
				},
				children: "Сохранить"
			})]
		}) : null,
		manual ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Manual, {
			categories: timeCats,
			onClose: () => setManual(false),
			onSave: (category, start, end) => {
				const a = combine(day, start);
				const b = combine(day, end);
				if (!a || !b || new Date(b) <= new Date(a)) return;
				addManualSpan(category, day, a, b);
				setManual(false);
			}
		}) : null
	] });
}
function combine(day, hhmm) {
	const match = /^(\d{1,2}):(\d{2})$/.exec(hhmm.trim());
	if (!match) return "";
	const hours = Number(match[1]);
	const minutes = Number(match[2]);
	if (hours > 23 || minutes > 59) return "";
	const [y, m, d] = day.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d, hours, minutes, 0).toISOString();
}
function Manual({ categories, onClose, onSave }) {
	const [category, setCategory] = (0, import_react.useState)(categories[0] ?? "");
	const [start, setStart] = (0, import_react.useState)("09:00");
	const [end, setEnd] = (0, import_react.useState)("10:00");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: "Интервал вручную",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Категория",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: inputClass,
					value: category,
					onChange: (event) => setCategory(event.target.value),
					children: categories.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: name }, name))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Начало",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: start,
					onChange: (event) => setStart(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Конец",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: end,
					onChange: (event) => setEnd(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "w-full rounded-full bg-gold py-3 text-ink",
				onClick: () => onSave(category, start, end),
				children: "Добавить"
			})
		]
	});
}
var SplitComponent = TimingView;
//#endregion
export { SplitComponent as component };
