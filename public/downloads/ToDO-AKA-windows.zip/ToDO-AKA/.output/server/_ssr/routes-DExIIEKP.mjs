import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Flame, t as Zap } from "../_libs/lucide-react.mjs";
import { _ as streakCount, d as fmtHm, f as fmtSpan, g as spanSeconds, i as playStart, l as dayKey, m as levelInfo, o as playTap, p as formatDay, u as dayScore, v as usePlanner } from "./router-Dr7Ztepa.mjs";
import { t as ScorePips } from "./score-pips-DcHkqQF0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DExIIEKP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Today() {
	const tasks = usePlanner((s) => s.tasks);
	const spans = usePlanner((s) => s.spans);
	const xp = usePlanner((s) => s.xp);
	const timeCats = usePlanner((s) => s.timeCats);
	const completeTask = usePlanner((s) => s.completeTask);
	const startSpan = usePlanner((s) => s.startSpan);
	const stopSpan = usePlanner((s) => s.stopSpan);
	const updateSpan = usePlanner((s) => s.updateSpan);
	const startPomo = usePlanner((s) => s.startPomo);
	const pausePomo = usePlanner((s) => s.pausePomo);
	const stopPomo = usePlanner((s) => s.stopPomo);
	const pomo = usePlanner((s) => s.pomo);
	const [pomoTask, setPomoTask] = (0, import_react.useState)("");
	const today = dayKey();
	const [, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setTick((n) => n + 1), 1e3);
		return () => window.clearInterval(id);
	}, []);
	const open = spans.find((span) => span.day === today && !span.end);
	const finished = spans.filter((span) => span.day === today && span.end).sort((a, b) => b.start.localeCompare(a.start));
	const unrated = finished.filter((span) => !span.score);
	const score = dayScore(spans, today);
	const seconds = spans.filter((span) => span.day === today).reduce((sum, span) => sum + spanSeconds(span), 0);
	const done = tasks.filter((task) => task.completed.slice(0, 10) === today).length;
	const pomos = tasks.reduce((sum, task) => sum + (task.completed.slice(0, 10) === today ? task.pomodoros : 0), 0);
	const openTasks = tasks.filter((task) => task.status !== "Выполнено").slice(0, 5);
	const level = levelInfo(xp);
	const streak = streakCount(tasks, spans);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm tracking-wide text-mist uppercase",
				children: "Сегодня"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl capitalize",
				children: formatDay(today)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line bg-panel p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-ember",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: "Серия"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-5xl",
								children: streak
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mist",
								children: streak ? "дней без пропуска" : "закрой дело — серия начнётся"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line bg-panel p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm",
									children: ["Уровень ", level.level]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 font-display text-2xl",
								children: [xp, " XP"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2 overflow-hidden rounded-full bg-panel-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-gold",
									style: { width: `${level.into / level.need * 100}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-mist",
								children: [
									level.into,
									" / ",
									level.need,
									" до следующего"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex items-center gap-4 rounded-card border border-line bg-panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rings, {
							time: Math.min(1, seconds / 28800),
							tasks: Math.min(1, done / 3),
							pomos: Math.min(1, pomos / 4)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm text-mist",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: "Время"
									}),
									" ",
									fmtHm(seconds),
									" / 8:00"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-ember",
										children: "Дела"
									}),
									" ",
									done,
									" / 3"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-cream",
										children: "Помидоры"
									}),
									" ",
									pomos,
									" / 4"
								] })
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [
					open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-wide text-gold uppercase",
								children: "Сейчас"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl",
								children: open.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-mist",
								children: fmtSpan(spanSeconds(open))
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								playTap();
								stopSpan(today);
							},
							className: "rounded-full bg-ember px-4 py-2 text-ink",
							children: "Стоп"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-mist",
						children: "Выбери, чем занят. Следующая категория сама закроет эту."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: timeCats.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								playStart();
								startSpan(name);
							},
							className: `rounded-full px-3 py-2 text-sm ${open?.category === name ? "bg-gold text-ink" : "bg-panel-2 text-cream"}`,
							children: name
						}, name))
					}),
					unrated.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-3 border-t border-line pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-mist",
							children: "Как прошёл этап"
						}), unrated.map((span) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm",
							children: span.category
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorePips, {
							value: span.score,
							onPick: (value) => updateSpan(span.id, { score: value })
						})] }, span.id))]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-mist",
						children: [
							"Оценка дня",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-cream",
								children: score ?? "—"
							}),
							score != null ? ` из ${finished.filter((span) => span.score).length} этапов` : " — оцени закрытые этапы"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pomodoro, {
				tasks: tasks.filter((task) => task.status !== "Выполнено"),
				taskId: pomoTask,
				onTask: setPomoTask,
				pomo,
				now: Date.now(),
				onStart: (minutes) => {
					playStart();
					startPomo(minutes, pomoTask, "focus");
				},
				onBreak: () => startPomo(5, pomo.taskId, "break"),
				onPause: pausePomo,
				onStop: stopPomo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Ближайшие дела"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/tasks",
					className: "text-sm text-gold",
					children: "Все задачи"
				})]
			}), openTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-card border border-dashed border-line p-6 text-mist",
				children: "Список пуст. Добавь одно дело — и закрой его."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: openTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-card border border-line bg-panel px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Выполнить",
							onClick: () => completeTask(task.id),
							className: "size-8 shrink-0 rounded-full border-2 border-gold"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate",
								children: task.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-mist",
								children: [
									"Поставлена ",
									new Date(task.created).toLocaleString("ru-RU", {
										day: "numeric",
										month: "short",
										hour: "2-digit",
										minute: "2-digit"
									}),
									" · ",
									"дедлайн ",
									task.deadline ? (/* @__PURE__ */ new Date(task.deadline + "T00:00:00")).toLocaleDateString("ru-RU", {
										day: "numeric",
										month: "short"
									}) : "не задан",
									" · ",
									task.priority
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								playStart();
								startPomo(25, task.id);
							},
							className: "rounded-full bg-gold px-3 py-2 text-sm text-ink",
							children: "25 мин"
						})
					]
				}, task.id))
			})] })
		]
	});
}
function Pomodoro({ tasks, taskId, onTask, pomo, now, onStart, onBreak, onPause, onStop }) {
	const left = pomo.running ? Math.max(0, Math.round((pomo.endsAt - now) / 1e3)) : pomo.remaining;
	const active = pomo.running || pomo.mode === "break";
	const linked = tasks.find((task) => task.id === (pomo.running || pomo.mode === "break" ? pomo.taskId : taskId));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-gold bg-panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide text-gold uppercase",
						children: "Помидор"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: active ? fmtSpan(left) : "25 минут одного дела"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-mist",
						children: pomo.mode === "break" ? "Фокус закрыт. Пять минут не трогай задачу, потом следующий круг." : "Один круг: 25 или 50 минут без переключений, затем 5 минут отдыха. Четыре круга за день закрывают кольцо."
					})
				] }), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [pomo.mode === "break" && !pomo.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBreak,
						className: "rounded-full bg-gold px-4 py-2 text-ink",
						children: "Перерыв 5 мин"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onPause,
						className: "rounded-full bg-panel-2 px-4 py-2",
						children: pomo.running ? "Пауза" : "Дальше"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onStop,
						className: "rounded-full bg-ember px-4 py-2 text-ink",
						children: "Сбросить"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onStart(25),
						className: "rounded-full bg-gold px-4 py-2 text-ink",
						children: "Старт 25"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onStart(50),
						className: "rounded-full bg-panel-2 px-4 py-2",
						children: "Старт 50"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm text-mist",
				children: ["К какой задаче", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "mt-1 w-full rounded-xl border border-line bg-panel-2 px-3 py-3 text-cream",
					value: active ? pomo.taskId : taskId,
					onChange: (event) => onTask(event.target.value),
					disabled: active,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Без задачи"
					}), tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: task.id,
						children: task.title
					}, task.id))]
				})]
			}),
			linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-gold",
				children: linked.title
			}) : null
		]
	});
}
function Rings({ time, tasks, pomos }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 120 120",
		className: "size-28 shrink-0",
		children: [
			{
				r: 46,
				pct: time,
				color: "var(--color-gold)"
			},
			{
				r: 34,
				pct: tasks,
				color: "var(--color-ember)"
			},
			{
				r: 22,
				pct: pomos,
				color: "var(--color-cream)"
			}
		].map((ring) => {
			const c = 2 * Math.PI * ring.r;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: ring.r,
				fill: "none",
				stroke: "var(--color-line)",
				strokeWidth: "8"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: ring.r,
				fill: "none",
				stroke: ring.color,
				strokeWidth: "8",
				strokeLinecap: "round",
				strokeDasharray: `${c * ring.pct} ${c}`,
				transform: "rotate(-90 60 60)"
			})] }, ring.r);
		})
	});
}
var SplitComponent = Today;
//#endregion
export { SplitComponent as component };
