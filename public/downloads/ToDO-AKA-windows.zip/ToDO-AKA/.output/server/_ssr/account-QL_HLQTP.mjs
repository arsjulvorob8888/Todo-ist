import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import "./client-NJ0UgcZn.mjs";
import { n as syncNow, r as useSyncStatus } from "./router-aju2iEXR.mjs";
import "./modal-B9fcrG3Z.mjs";
import { t as DesktopDownload } from "./desktop-download-CQnZm49J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-QL_HLQTP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEV_STATE = {
	user: {
		id: "dev-user",
		displayName: "Dev User",
		primaryEmail: "dev@example.com",
		profileImageUrl: null,
		isDevFallback: true
	},
	isPending: false
};
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return DEV_STATE;
}
function AccountView() {
	const { user, isPending } = useCurrentUserState();
	const { status } = useSyncStatus();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	Boolean(user && !user.isDevFallback);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Личный кабинет"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Аккаунт"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mt-4 rounded-card border border-gold bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide text-gold uppercase",
						children: "Тариф"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: "BETA FREE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mist",
						children: "Один план на время беты ToDO-AKA. Проекты, метки, помидор и синхронизация телефона с компьютером — без оплаты."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopDownload, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-mist",
				children: [
					"Связь: ",
					statusText(status),
					". Без интернета всё остаётся на устройстве и уходит на сервер, когда сеть вернётся."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 rounded-full bg-panel-2 px-4 py-2 text-sm",
				onClick: () => void syncNow(),
				children: "Синхронизировать"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-mist",
				children: "В этом окне предпросмотра вход выключен, данные остаются на устройстве. На опубликованном сайте здесь будет регистрация по почте — один аккаунт для телефона и компьютера."
			}),
			null,
			null,
			null
		]
	});
}
function statusText(status) {
	if (status === "offline") return "офлайн, работаю локально";
	if (status === "sync") return "синхронизирую";
	if (status === "ok") return "синхронизировано";
	return "только это устройство";
}
var SplitComponent = AccountView;
//#endregion
export { SplitComponent as component };
