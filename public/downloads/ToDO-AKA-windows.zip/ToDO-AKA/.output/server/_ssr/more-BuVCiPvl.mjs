import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as usePlanner } from "./router-Dr7Ztepa.mjs";
import { n as Modal, r as inputClass, t as Field } from "./modal-B9fcrG3Z.mjs";
import { t as DesktopDownload } from "./desktop-download-_HpADY1Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-BuVCiPvl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MoreView() {
	const projects = usePlanner((s) => s.projects);
	const timeCats = usePlanner((s) => s.timeCats);
	const addCategory = usePlanner((s) => s.addCategory);
	const renameCategory = usePlanner((s) => s.renameCategory);
	const deleteCategory = usePlanner((s) => s.deleteCategory);
	const contacts = usePlanner((s) => s.contacts);
	const ideas = usePlanner((s) => s.ideas);
	const books = usePlanner((s) => s.books);
	const addContact = usePlanner((s) => s.addContact);
	const addIdea = usePlanner((s) => s.addIdea);
	const addBook = usePlanner((s) => s.addBook);
	const [tab, setTab] = (0, import_react.useState)("time");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Справочники"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Ещё"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopDownload, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				["time", "Время"],
				["project", "Проекты"],
				["people", "Люди"],
				["ideas", "Идеи"],
				["books", "Книги"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(id),
				className: `rounded-full px-3 py-2 text-sm ${tab === id ? "bg-gold text-ink" : "bg-panel text-mist"}`,
				children: label
			}, id))
		}),
		tab === "time" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cats, {
			kind: "time",
			names: timeCats,
			onAdd: addCategory,
			onRename: renameCategory,
			onDelete: deleteCategory
		}) : null,
		tab === "project" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cats, {
			kind: "project",
			names: projects,
			onAdd: addCategory,
			onRename: renameCategory,
			onDelete: deleteCategory
		}) : null,
		tab === "people" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(People, {
			contacts,
			onAdd: addContact
		}) : null,
		tab === "ideas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ideas, {
			ideas,
			onAdd: addIdea
		}) : null,
		tab === "books" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Books, {
			books,
			onAdd: addBook
		}) : null
	] });
}
function Cats({ kind, names, onAdd, onRename, onDelete }) {
	const [name, setName] = (0, import_react.useState)("");
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [next, setNext] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: inputClass,
				placeholder: "Новая категория",
				value: name,
				onChange: (event) => setName(event.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "rounded-full bg-gold px-4 text-ink",
				onClick: () => {
					onAdd(kind, name);
					setName("");
				},
				children: "Добавить"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: names.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between rounded-2xl border border-line bg-panel px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-gold",
						onClick: () => {
							setEdit(item);
							setNext(item);
						},
						children: "Править"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-ember",
						onClick: () => onDelete(kind, item),
						children: "Удалить"
					})]
				})]
			}, item))
		}),
		edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: "Категория",
			onClose: () => setEdit(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Название",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: next,
					onChange: (event) => setNext(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "w-full rounded-full bg-gold py-3 text-ink",
				onClick: () => {
					onRename(kind, edit, next);
					setEdit(null);
				},
				children: "Сохранить"
			})]
		}) : null
	] });
}
function People({ contacts, onAdd }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [group, setGroup] = (0, import_react.useState)("");
	const [birthday, setBirthday] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-3 rounded-full bg-gold px-4 py-2 text-ink",
			onClick: () => setOpen(true),
			children: "Человек"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: contacts.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-panel px-3 py-3",
				children: [
					person.name,
					" · ",
					person.group || "без группы",
					" · ",
					person.birthday || "день рождения не указан"
				]
			}, person.id))
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: "Контакт",
			onClose: () => setOpen(false),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Имя",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Группа",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: group,
						onChange: (e) => setGroup(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "День рождения",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: birthday,
						onChange: (e) => setBirthday(e.target.value),
						placeholder: "14.05"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "w-full rounded-full bg-gold py-3 text-ink",
					onClick: () => {
						if (!name.trim()) return;
						onAdd({
							name: name.trim(),
							group,
							birthday
						});
						setOpen(false);
					},
					children: "Сохранить"
				})
			]
		}) : null
	] });
}
function Ideas({ ideas, onAdd }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: `${inputClass} mb-2`,
			placeholder: "Идея",
			value: title,
			onChange: (e) => setTitle(e.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: `${inputClass} mb-2`,
			rows: 3,
			placeholder: "Суть",
			value: note,
			onChange: (e) => setNote(e.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "rounded-full bg-gold px-4 py-2 text-ink",
			onClick: () => {
				if (!title.trim()) return;
				onAdd({
					title: title.trim(),
					note
				});
				setTitle("");
				setNote("");
			},
			children: "Записать"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-2",
			children: ideas.map((idea) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-panel px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: idea.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: idea.note
				})]
			}, idea.id))
		})
	] });
}
function Books({ books, onAdd }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [author, setAuthor] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex flex-col gap-2 sm:flex-row",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: inputClass,
				placeholder: "Книга",
				value: title,
				onChange: (e) => setTitle(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: inputClass,
				placeholder: "Автор",
				value: author,
				onChange: (e) => setAuthor(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "rounded-full bg-gold px-4 py-2 text-ink",
				onClick: () => {
					if (!title.trim()) return;
					onAdd({
						title: title.trim(),
						author
					});
					setTitle("");
					setAuthor("");
				},
				children: "Добавить"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: books.map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-2xl border border-line bg-panel px-3 py-3",
			children: [
				book.title,
				" — ",
				book.author,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-mist",
					children: book.date
				})
			]
		}, book.id))
	})] });
}
var SplitComponent = MoreView;
//#endregion
export { SplitComponent as component };
