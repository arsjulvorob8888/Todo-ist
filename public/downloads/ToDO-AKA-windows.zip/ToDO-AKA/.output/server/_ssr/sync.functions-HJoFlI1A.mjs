import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { $t as unknown, Ht as array, Jt as object, Ut as boolean, Zt as string, qt as number } from "../_libs/@better-auth/core+[...].mjs";
import { t as authMiddleware } from "./middleware-CO7pgAcK.mjs";
import { r as getSql } from "./db-BbmJcePj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sync.functions-HJoFlI1A.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var COLLECTIONS = /* @__PURE__ */ new Set([
	"tasks",
	"spans",
	"goals",
	"contacts",
	"ideas",
	"books",
	"boards",
	"labels",
	"meta"
]);
var changeSchema = object({
	collection: string().max(40),
	id: string().max(80),
	updatedAt: number().int(),
	deleted: boolean(),
	payload: unknown()
});
var bodySchema = object({
	since: number().int().nonnegative(),
	changes: array(changeSchema).max(2e3)
});
var pushPull_createServerFn_handler = createServerRpc({
	id: "29449fcaa9124460b3680cfd58a9430b91e7fbafebef68cb829855cc2472ebfb",
	name: "pushPull",
	filename: "src/lib/sync.functions.ts"
}, (opts) => pushPull.__executeServer(opts));
var pushPull = createServerFn({ method: "POST" }).middleware([authMiddleware]).inputValidator(bodySchema).handler(pushPull_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	const userId = context.userId;
	for (const change of data.changes) {
		if (!COLLECTIONS.has(change.collection)) continue;
		const payload = JSON.stringify(change.payload ?? {});
		await sql`
        insert into sync_records (user_id, collection, record_id, payload, updated_at, deleted)
        values (${userId}, ${change.collection}, ${change.id}, ${payload}, ${change.updatedAt}, ${change.deleted})
        on conflict (user_id, collection, record_id) do update
        set payload = excluded.payload,
            updated_at = excluded.updated_at,
            deleted = excluded.deleted
        where sync_records.updated_at <= excluded.updated_at
      `;
	}
	const rows = await sql`
      select collection, record_id, payload, updated_at, deleted
      from sync_records
      where user_id = ${userId} and updated_at > ${data.since}
      order by updated_at asc
      limit 2000
    `;
	return {
		now: Date.now(),
		records: rows.map((row) => ({
			collection: row.collection,
			id: row.record_id,
			updatedAt: Number(row.updated_at),
			deleted: Boolean(row.deleted),
			payload: JSON.parse(row.payload)
		}))
	};
});
//#endregion
export { pushPull_createServerFn_handler };
