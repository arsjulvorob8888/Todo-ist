//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CEExbcvX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/account",
			"/goals",
			"/more",
			"/stats",
			"/tasks",
			"/timing"
		],
		preloads: ["/assets/index-CqmKiHv0.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CqmKiHv0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-JjBpIP97.js", "/assets/score-pips-CoT_slQJ.js"]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-BYHQAz7Z.js",
			"/assets/client-B1yhqWqJ.js",
			"/assets/modal-DXOk1fdd.js",
			"/assets/desktop-download-RgU44mlw.js"
		]
	},
	"/goals": {
		filePath: "/workspace/src/routes/goals.tsx",
		children: void 0,
		preloads: ["/assets/goals-BbU-ESzK.js", "/assets/modal-DXOk1fdd.js"]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-CrB6zi0A.js",
			"/assets/modal-DXOk1fdd.js",
			"/assets/desktop-download-RgU44mlw.js"
		]
	},
	"/stats": {
		filePath: "/workspace/src/routes/stats.tsx",
		children: void 0,
		preloads: ["/assets/stats-DCinKl57.js"]
	},
	"/tasks": {
		filePath: "/workspace/src/routes/tasks.tsx",
		children: void 0,
		preloads: ["/assets/tasks-DQdKX5j2.js", "/assets/modal-DXOk1fdd.js"]
	},
	"/timing": {
		filePath: "/workspace/src/routes/timing.tsx",
		children: void 0,
		preloads: [
			"/assets/timing-BbdIbCui.js",
			"/assets/modal-DXOk1fdd.js",
			"/assets/score-pips-CoT_slQJ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
